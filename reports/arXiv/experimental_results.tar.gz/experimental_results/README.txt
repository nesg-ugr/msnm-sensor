Folder structure and contents. Someone interested on [Not included] folders, please ask the authors for that. The explained folder structure shown for the BR is exactly the same in the other sensors.

.
├── data
│   └── metis_batch_60obs
│       ├── 20170920_182121 		// Root folder
│       │   ├── borderRouter 		// Sensor folder
│       │   │   ├── data 		
│       │   │   │   ├── calibration	// [Not included] Contains every parameters used when a new calibration process is done (every hour)
│       │   │   │   ├── diagnosis	// [Not included] Ongoing work, diagnosis results
│       │   │   │   ├── monitoring	// monitoring information. output folder contains the computed Q and D statistics per minute while 					 	// observation folder includes all observation obtained after parsing process (Feature as a counter).
│       │   │   │   └── sources		// [Not included] Local and remote sources (raw)
│       │   ├── borderRouter.yaml	// Configuration file for the border router
│       │   ├── global.yaml		// Functional conections of MSNM-Sensors. This is used by the dashboard to draw the sensors connections.
│       │   ├── netflow_parser.yaml	// Configuration files for the parser taking into account netflow based local sources.
│       │   ├── netflow.yaml
│       │   ├── routerR1
│       │   │   └── data
│       │   │       ├── calibration	
│       │   │       ├── diagnosis
│       │   │       ├── monitoring
│       │   │       └── sources
│       │   ├── routerR1.yaml		// Configuration file for the router R1
│       │   ├── routerR2
│       │   │   └── data
│       │   │       ├── calibration
│       │   │       ├── diagnosis
│       │   │       ├── monitoring
│       │   │       └── sources
│       │   ├── routerR2.yaml		// Configuration file for the router R2
│       │   ├── routerR3
│       │   │   └── data
│       │   │       ├── calibration
│       │   │       ├── diagnosis
│       │   │       ├── monitoring
│       │   │       └── sources
│       │   └── routerR3.yaml		// Configuration file for the router R3
│       └── outputs			// Post processing results. Obtaning by running the corresponding notebook
│           └── figs
│               ├── borderRouter_all_q_d.pdf
│               ├── borderRouter_all_q_d_zoom.pdf
│               ├── borderRouter_anomaly_q_d.pdf
│               ├── routerR1_all_q_d.pdf
│               ├── routerR1_anomaly_q_d.pdf
│               ├── routerR2_all_q_d.pdf
│               ├── routerR2_anomaly_q_d.pdf
│               ├── routerR3_all_q_d.pdf
│               └── routerR3_anomaly_q_d.pdf
├── notebook
│   └── q_d_study_github.ipynb		// The jupyter notebook to run


